var category = require('../controller/categoryController');
var express = require('express');
var router = express.Router();

router.get('/categories',category.getCategory);
router.post('/add',category.addCategory);

module.exports = router;